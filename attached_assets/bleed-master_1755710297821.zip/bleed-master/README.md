# bleed-src
this src is for discord skids who enjoy skidding discord bots on github.com :)
